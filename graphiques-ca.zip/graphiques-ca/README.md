# Graphiques CA — Alphitan

Générateur de graphiques de chiffre d’affaires aux couleurs Alphitan. Il propose cinq types : évolution, comparatif groupé, pont, courbe et histogramme + courbe. L’outil comprend des dossiers, des modèles et des exports PNG et SVG.

Les graphiques, dossiers et modèles sont stockés dans une base **Neon** (Postgres). Le site est hébergé sur **Netlify** à partir de ce dépôt **GitHub**. Neon ne sert que la base de données : l’application et l’API sont servies par Netlify.

```
graphiques-ca/
├── public/
│   └── index.html              L’application (un seul fichier)
├── netlify/
│   └── functions/
│       └── api.mjs             API /api/* qui lit et écrit dans Neon
├── db/
│   └── schema.sql              Tables et vue de consultation
├── netlify.toml                Configuration Netlify
├── package.json                Dépendance : @neondatabase/serverless
├── package-lock.json
├── .env.example                Variables à renseigner
└── .gitignore
```

## Mise en route

### 1. Créer la base Neon

1. Sur [console.neon.tech](https://console.neon.tech), créez un projet (région conseillée : *AWS Europe Central, Frankfurt*).
2. Cliquez sur **Connect**, cochez **Connection pooling**, puis copiez la chaîne de connexion. Elle commence par `postgresql://` et contient `-pooler`.
3. Facultatif : dans **SQL Editor**, collez et exécutez `db/schema.sql`. Sinon, les tables sont créées automatiquement au premier appel. Seule la vue de consultation `v_graphiques` demande d’exécuter ce fichier.

### 2. Déposer le dossier sur GitHub

Créez un dépôt **privé** nommé `graphiques-ca`, puis, depuis ce dossier :

```bash
git init
git add .
git commit -m "Graphiques CA : première version"
git branch -M main
git remote add origin https://github.com/VOTRE-COMPTE/graphiques-ca.git
git push -u origin main
```

Vous pouvez aussi passer par l’interface web : **Add file → Upload files**, puis glisser le contenu du dossier. Vérifiez que `.gitignore` est bien envoyé, car certains systèmes masquent les fichiers commençant par un point.

### 3. Déployer sur Netlify

1. **Add new site → Import an existing project → GitHub**, puis choisissez `graphiques-ca`. Les réglages de build sont lus dans `netlify.toml` : il n’y a rien à saisir.
2. **Site configuration → Environment variables**, ajoutez :
   - `DATABASE_URL` : la chaîne de connexion Neon de l’étape 1 (cochez *Contains secret values*) ;
   - `ACCESS_TOKEN` : un code d’accès long, que vous communiquerez aux personnes autorisées.
3. Lancez un déploiement (**Deploys → Trigger deploy**) pour que les variables soient prises en compte.

Variante : la fonctionnalité **Netlify DB** crée elle-même une base Neon (`npx netlify db init`) et renseigne `NETLIFY_DATABASE_URL`. La fonction lit cette variable automatiquement si `DATABASE_URL` est absente.

### 4. Première connexion

Ouvrez l’adresse du site et saisissez le code d’accès (`ACCESS_TOKEN`). Il est mémorisé dans le navigateur.

### 5. Récupérer les graphiques de la version Claude

Dans l’outil publié sur Claude, ouvrez **Mes graphiques**, puis cliquez sur **Exporter une sauvegarde** : un fichier `.json` est téléchargé. Sur le site Netlify, faites **Mes graphiques → Importer une sauvegarde** avec ce fichier. Graphiques, dossiers et modèles sont recréés à l’identique.

## Voir les données dans Neon

Dans la console Neon, l’onglet **Tables** affiche `charts`, `folders` et `templates`. Le contenu de chaque graphique (titres, données, réglages) se trouve dans la colonne JSON `block`.

Quelques requêtes utiles dans **SQL Editor** :

```sql
-- Liste lisible des graphiques (vue créée par db/schema.sql)
select * from v_graphiques;

-- Graphiques d’un dossier
select c.name, c.type
from charts c join folders f on f.id = c.folder_id
where f.name = 'Septembre';

-- Titre et lignes d’un pont
select name, block ->> 'title' as titre, jsonb_array_length(block -> 'steps') as postes
from charts where type = 'pont';
```

Évitez de modifier `block` à la main : l’application attend une structure précise.

## Développement local

```bash
npm install
cp .env.example .env      # puis renseignez DATABASE_URL et ACCESS_TOKEN
npx netlify dev           # http://localhost:8888
```

Ouvert directement depuis le disque (`public/index.html`), l’outil fonctionne aussi. Il enregistre alors dans le navigateur, puis transfère ces éléments vers la base à la première connexion réussie.

## Sécurité et limites

- La chaîne de connexion Neon ne quitte jamais le serveur : le navigateur ne parle qu’à `/api`, protégé par `ACCESS_TOKEN`.
- Toute personne qui a le code d’accès voit et modifie le même espace de graphiques. Pour retirer un accès, changez `ACCESS_TOKEN` puis redéployez.
- Gardez le dépôt privé et ne versionnez jamais le fichier `.env`.
- En cas d’enregistrements simultanés sur un même graphique, la dernière version enregistrée l’emporte.
