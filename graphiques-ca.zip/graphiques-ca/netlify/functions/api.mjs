// API Graphiques CA : lecture et écriture des graphiques, dossiers et modèles dans Neon (Postgres).
// Route : /api/all (GET), /api/{charts|folders|templates}/{id} (PUT, DELETE).
import { neon } from '@neondatabase/serverless';
import { timingSafeEqual } from 'node:crypto';

const DB_URL = process.env.DATABASE_URL || process.env.NETLIFY_DATABASE_URL;
const sql = DB_URL ? neon(DB_URL) : null;

const TYPES = new Set(['evo', 'grp', 'pont', 'line', 'combo']);
const ID_RE = /^[A-Za-z0-9_-]{1,64}$/;
const MAX_BODY = 256 * 1024;

let schemaReady = null;
function ensureSchema() {
  if (!schemaReady) {
    schemaReady = (async () => {
      await sql`create table if not exists folders (
        id text primary key, name text not null, parent_id text,
        created_at bigint not null, updated_at bigint not null)`;
      await sql`create index if not exists folders_parent_idx on folders (parent_id)`;
      await sql`create table if not exists charts (
        id text primary key, name text not null, custom_name boolean not null default false,
        type text not null, folder_id text, block jsonb not null, common jsonb not null default '{}'::jsonb,
        created_at bigint not null, updated_at bigint not null)`;
      await sql`create index if not exists charts_folder_idx on charts (folder_id)`;
      await sql`create table if not exists templates (
        id text primary key, name text not null, type text not null,
        block jsonb not null, common jsonb not null default '{}'::jsonb,
        created_at bigint not null, updated_at bigint not null)`;
    })().catch((e) => { schemaReady = null; throw e; });
  }
  return schemaReady;
}

const json = (status, data) => new Response(JSON.stringify(data), {
  status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' },
});

function authorized(req) {
  const expected = Buffer.from(process.env.ACCESS_TOKEN || '');
  const got = Buffer.from(req.headers.get('x-access-token') || '');
  return expected.length > 0 && got.length === expected.length && timingSafeEqual(got, expected);
}

const num = (v) => (v == null ? null : Number(v));
const ts = (v) => (Number.isFinite(Number(v)) && Number(v) > 0 ? Math.round(Number(v)) : Date.now());
const str = (v, max = 300) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const optId = (v) => (typeof v === 'string' && ID_RE.test(v) ? v : null);
const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);

const toChart = (r) => ({ id: r.id, name: r.name, customName: r.custom_name, type: r.type, folderId: r.folder_id,
  block: r.block, common: r.common, createdAt: num(r.created_at), updatedAt: num(r.updated_at) });
const toFolder = (r) => ({ id: r.id, name: r.name, parentId: r.parent_id, createdAt: num(r.created_at), updatedAt: num(r.updated_at) });
const toTemplate = (r) => ({ id: r.id, name: r.name, type: r.type, block: r.block, common: r.common,
  createdAt: num(r.created_at), updatedAt: num(r.updated_at) });

async function upsert(kind, id, b) {
  if (kind === 'charts') {
    if (!TYPES.has(b.type) || !isObj(b.block)) return 'Graphique invalide';
    await sql`insert into charts (id, name, custom_name, type, folder_id, block, common, created_at, updated_at)
      values (${id}, ${str(b.name) || 'Graphique sans titre'}, ${!!b.customName}, ${b.type}, ${optId(b.folderId)},
              ${JSON.stringify(b.block)}::jsonb, ${JSON.stringify(isObj(b.common) ? b.common : {})}::jsonb, ${ts(b.createdAt)}, ${ts(b.updatedAt)})
      on conflict (id) do update set name = excluded.name, custom_name = excluded.custom_name, type = excluded.type,
        folder_id = excluded.folder_id, block = excluded.block, common = excluded.common, updated_at = excluded.updated_at`;
  } else if (kind === 'folders') {
    const parent = optId(b.parentId);
    if (parent === id) return 'Un dossier ne peut pas être son propre parent';
    await sql`insert into folders (id, name, parent_id, created_at, updated_at)
      values (${id}, ${str(b.name, 120) || 'Nouveau dossier'}, ${parent}, ${ts(b.createdAt)}, ${ts(b.updatedAt)})
      on conflict (id) do update set name = excluded.name, parent_id = excluded.parent_id, updated_at = excluded.updated_at`;
  } else {
    if (!TYPES.has(b.type) || !isObj(b.block)) return 'Modèle invalide';
    await sql`insert into templates (id, name, type, block, common, created_at, updated_at)
      values (${id}, ${str(b.name) || 'Modèle sans nom'}, ${b.type}, ${JSON.stringify(b.block)}::jsonb,
              ${JSON.stringify(isObj(b.common) ? b.common : {})}::jsonb, ${ts(b.createdAt)}, ${ts(b.updatedAt)})
      on conflict (id) do update set name = excluded.name, type = excluded.type, block = excluded.block,
        common = excluded.common, updated_at = excluded.updated_at`;
  }
  return null;
}

async function remove(kind, id) {
  if (kind === 'charts') await sql`delete from charts where id = ${id}`;
  else if (kind === 'folders') await sql`delete from folders where id = ${id}`;
  else await sql`delete from templates where id = ${id}`;
}

export default async (req) => {
  if (!sql) return json(503, { error: 'DATABASE_URL non configurée sur Netlify' });
  if (!process.env.ACCESS_TOKEN) return json(503, { error: 'ACCESS_TOKEN non configuré sur Netlify' });
  if (!authorized(req)) return json(401, { error: 'Code d’accès invalide' });

  let parts;
  try { parts = new URL(req.url).pathname.replace(/^\/api\/?/, '').split('/').filter(Boolean).map(decodeURIComponent); }
  catch { return json(400, { error: 'Adresse invalide' }); }
  const isAll = parts.length === 1 && parts[0] === 'all';
  const [kind, id] = parts;
  if (!isAll && (parts.length !== 2 || !['charts', 'folders', 'templates'].includes(kind) || !ID_RE.test(id || ''))) {
    return json(404, { error: 'Route inconnue' });
  }
  if (isAll ? req.method !== 'GET' : !['PUT', 'DELETE'].includes(req.method)) return json(405, { error: 'Méthode non autorisée' });
  try {
    await ensureSchema();
    if (isAll) {
      const [c, f, t] = await Promise.all([
        sql`select * from charts order by updated_at desc`,
        sql`select * from folders order by name`,
        sql`select * from templates order by name`,
      ]);
      return json(200, { charts: c.map(toChart), folders: f.map(toFolder), templates: t.map(toTemplate) });
    }
    if (req.method === 'DELETE') { await remove(kind, id); return json(200, { ok: true }); }
    const text = await req.text();
    if (text.length > MAX_BODY) return json(413, { error: 'Document trop volumineux' });
    let body; try { body = JSON.parse(text); } catch { return json(400, { error: 'JSON invalide' }); }
    if (!isObj(body)) return json(400, { error: 'JSON invalide' });
    const err = await upsert(kind, id, body);
    return err ? json(400, { error: err }) : json(200, { ok: true });
  } catch (e) {
    console.error(e);
    return json(500, { error: 'Erreur de base de données' });
  }
};

export const config = { path: '/api/*' };
