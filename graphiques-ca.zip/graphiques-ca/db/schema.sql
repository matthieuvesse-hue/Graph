-- Schéma Graphiques CA pour Neon (Postgres).
-- La fonction Netlify crée ces tables automatiquement au premier appel ;
-- ce fichier sert à les créer à la main dans l’éditeur SQL de Neon si vous le préférez.

create table if not exists folders (
  id          text primary key,
  name        text   not null,
  parent_id   text,                       -- null = racine « Mes graphiques »
  created_at  bigint not null,            -- horodatage en millisecondes
  updated_at  bigint not null
);
create index if not exists folders_parent_idx on folders (parent_id);

create table if not exists charts (
  id           text primary key,
  name         text    not null,
  custom_name  boolean not null default false,
  type         text    not null,          -- evo, grp, pont, line, combo
  folder_id    text,                      -- null = racine
  block        jsonb   not null,          -- titres, données et réglages du graphique
  common       jsonb   not null default '{}'::jsonb,  -- unité et fond
  created_at   bigint  not null,
  updated_at   bigint  not null
);
create index if not exists charts_folder_idx on charts (folder_id);

create table if not exists templates (
  id          text primary key,
  name        text   not null,
  type        text   not null,
  block       jsonb  not null,
  common      jsonb  not null default '{}'::jsonb,
  created_at  bigint not null,
  updated_at  bigint not null
);

-- Vue de consultation lisible dans la console Neon
create or replace view v_graphiques as
select c.name                                  as graphique,
       c.type,
       coalesce(f.name, 'Mes graphiques')      as dossier,
       to_timestamp(c.updated_at / 1000.0)     as modifie_le,
       c.block ->> 'title'                     as titre
from charts c
left join folders f on f.id = c.folder_id
order by c.updated_at desc;
